class Reminder {
  String medicineName;
  DateTime dateTime;

  Reminder({required this.medicineName, required this.dateTime});
}
