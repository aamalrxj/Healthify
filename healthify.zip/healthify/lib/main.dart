import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:provider/provider.dart';
import 'dart:math';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Healthify',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: ChangeNotifierProvider(
        create: (context) => ReminderProvider(),
        child: const MyHomePage(),
      ),
    );
  }
}

class Reminder {
  final String medicineName;
  final DateTime dateTime;

  Reminder({required this.medicineName, required this.dateTime});
}

class DoctorVisit {
  final String doctorName;
  final DateTime visitDateTime;

  DoctorVisit({required this.doctorName, required this.visitDateTime});
}

class MedicalReport {
  final String condition;
  final DateTime reportDateTime;

  MedicalReport({required this.condition, required this.reportDateTime});
}

class ReminderProvider extends ChangeNotifier {
  List<Reminder> medicineReminders = [];
  List<DoctorVisit> doctorVisits = [];
  List<MedicalReport> medicalReports = [];

  void addMedicineReminder(Reminder reminder) {
    medicineReminders.add(reminder);
    notifyListeners();
  }

  void addDoctorVisit(DoctorVisit visit) {
    doctorVisits.add(visit);
    notifyListeners();
  }

  void addMedicalReport(MedicalReport report) {
    medicalReports.add(report);
    notifyListeners();
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
  FlutterLocalNotificationsPlugin();
  final TextEditingController medicineController = TextEditingController();
  DateTime? selectedMedicineDate;
  TimeOfDay? selectedMedicineTime;

  final List<String> doctorNames = [
    "Dr. Smith",
    "Dr. Johnson",
    "Dr. Williams",
    "Dr. Brown",
    "Dr. Jones",
    "Dr. Garcia",
    "Dr. Miller",
    "Dr. Davis",
    "Dr. Rodriguez",
    "Dr. Martinez"
  ];

  final List<String> medicalConditions = [
    "Hypertension",
    "Diabetes",
    "Asthma",
    "Cardiovascular Disease",
    "Allergy",
    "Influenza",
    "Arthritis",
    "Gastroesophageal Reflux Disease",
    "Chronic Pain",
    "Depression"
  ];

  @override
  void initState() {
    super.initState();
    _initializeNotifications();
    _initializeTimeZones();
  }

  Future<void> _initializeNotifications() async {
    const AndroidInitializationSettings initializationSettingsAndroid =
    AndroidInitializationSettings('@mipmap/ic_launcher');

    const InitializationSettings initializationSettings =
    InitializationSettings(android: initializationSettingsAndroid);

    await flutterLocalNotificationsPlugin.initialize(initializationSettings);
  }

  Future<void> _initializeTimeZones() async {
    tz.initializeTimeZones(); // Initialize time zones
  }

  Future<void> _scheduleNotification(Reminder reminder) async {
    await flutterLocalNotificationsPlugin.zonedSchedule(
      0,
      'Medicine Reminder',
      'Time to take your medicine: ${reminder.medicineName}!',
      tz.TZDateTime.from(reminder.dateTime, tz.local),
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'your_channel_id',
          'your_channel_name',
          channelDescription: 'Your channel description',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
      androidScheduleMode: AndroidScheduleMode.exact,
      matchDateTimeComponents: DateTimeComponents.time,
      uiLocalNotificationDateInterpretation:
      UILocalNotificationDateInterpretation.absoluteTime,
    );
  }

  Future<void> _selectMedicineDate(BuildContext context) async {
    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: selectedMedicineDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2101),
    );

    if (pickedDate != null && pickedDate != selectedMedicineDate) {
      setState(() {
        selectedMedicineDate = pickedDate;
      });
    }
  }

  Future<void> _selectMedicineTime(BuildContext context) async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: selectedMedicineTime ?? TimeOfDay.now(),
    );

    if (pickedTime != null && pickedTime != selectedMedicineTime) {
      setState(() {
        selectedMedicineTime = pickedTime;
      });
    }
  }

  void _addMedicineReminder() {
    if (medicineController.text.isNotEmpty && selectedMedicineDate != null && selectedMedicineTime != null) {
      final DateTime reminderDateTime = DateTime(
        selectedMedicineDate!.year,
        selectedMedicineDate!.month,
        selectedMedicineDate!.day,
        selectedMedicineTime!.hour,
        selectedMedicineTime!.minute,
      );

      Reminder reminder = Reminder(
        medicineName: medicineController.text,
        dateTime: reminderDateTime,
      );

      // Add the reminder to the provider and schedule the notification
      Provider.of<ReminderProvider>(context, listen: false).addMedicineReminder(reminder);
      _scheduleNotification(reminder);

      // Clear the fields after adding the reminder
      medicineController.clear();
      setState(() {
        selectedMedicineDate = null;
        selectedMedicineTime = null;
      });
    }
  }

  void _generateRandomDoctorVisit() {
    final Random random = Random();
    final int randomDays = random.nextInt(30); // Random days within the next 30 days
    final DateTime now = DateTime.now();
    final DateTime randomDate = now.add(Duration(days: randomDays));

    // Generate a random time (between 9:00 AM and 5:00 PM)
    final int randomHours = 9 + random.nextInt(9); // 9 AM to 5 PM
    final int randomMinutes = random.nextInt(60);
    DateTime randomVisitTime = DateTime(randomDate.year, randomDate.month, randomDate.day, randomHours, randomMinutes);

    // Randomly select a doctor's name from the list
    final String randomDoctorName = doctorNames[random.nextInt(doctorNames.length)];

    // Add the generated visit time to the list in the provider
    DoctorVisit visit = DoctorVisit(doctorName: randomDoctorName, visitDateTime: randomVisitTime);
    Provider.of<ReminderProvider>(context, listen: false).addDoctorVisit(visit);

    // Show a message to the user
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Doctor Visit Suggested with $randomDoctorName at ${randomVisitTime.toLocal()}'),
    ));
  }

  void _generateRandomMedicalReport() {
    final Random random = Random();
    final int randomDays = random.nextInt(30); // Random days within the next 30 days
    final DateTime now = DateTime.now();
    final DateTime randomDate = now.add(Duration(days: randomDays));

    // Generate a random time (between 9:00 AM and 5:00 PM)
    final int randomHours = 9 + random.nextInt(9); // 9 AM to 5 PM
    final int randomMinutes = random.nextInt(60);
    DateTime randomReportTime = DateTime(randomDate.year, randomDate.month, randomDate.day, randomHours, randomMinutes);

    // Randomly select a medical condition from the list
    final String randomCondition = medicalConditions[random.nextInt(medicalConditions.length)];

    // Add the generated medical report to the list in the provider
    MedicalReport report = MedicalReport(condition: randomCondition, reportDateTime: randomReportTime);
    Provider.of<ReminderProvider>(context, listen: false).addMedicalReport(report);

    // Show a message to the user
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Random Medical Report Generated: $randomCondition on ${randomReportTime.toLocal()}'),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final medicineReminders = Provider.of<ReminderProvider>(context).medicineReminders;
    final doctorVisits = Provider.of<ReminderProvider>(context).doctorVisits;
    final medicalReports = Provider.of<ReminderProvider>(context).medicalReports;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Healthify'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Medicine Reminder Section
            TextField(
              controller: medicineController,
              decoration: const InputDecoration(
                labelText: 'Medicine Name',
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () => _selectMedicineDate(context),
                    child: Text(selectedMedicineDate == null
                        ? 'Select Date'
                        : 'Date: ${selectedMedicineDate!.toLocal()}'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextButton(
                    onPressed: () => _selectMedicineTime(context),
                    child: Text(selectedMedicineTime == null
                        ? 'Select Time'
                        : 'Time: ${selectedMedicineTime!.format(context)}'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _addMedicineReminder,
              child: const Text('Add Reminder'),
            ),

            // Scheduled Medicine Reminders
            const SizedBox(height: 20),
            const Text('Scheduled Medicine Reminders:', style: TextStyle(fontSize: 18)),
            Expanded(
              child: ListView.builder(
                itemCount: medicineReminders.length,
                itemBuilder: (context, index) {
                  final reminder = medicineReminders[index];
                  return ListTile(
                    title: Text(reminder.medicineName),
                    subtitle: Text('Reminder Time: ${reminder.dateTime.toLocal()}'),
                  );
                },
              ),
            ),

            // Doctor Visit Timings Section
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _generateRandomDoctorVisit,
              child: const Text('Generate Doctor Visit Timing'),
            ),
            const SizedBox(height: 20),
            const Text('Scheduled Doctor Visits:', style: TextStyle(fontSize: 18)),
            Expanded(
              child: ListView.builder(
                itemCount: doctorVisits.length,
                itemBuilder: (context, index) {
                  final visit = doctorVisits[index];
                  return ListTile(
                    title: Text('Visit to: ${visit.doctorName}'),
                    subtitle: Text('Visit Time: ${visit.visitDateTime.toLocal()}'),
                  );
                },
              ),
            ),

            // Medical Reports Section
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _generateRandomMedicalReport,
              child: const Text('Medical Report'),
            ),
            const SizedBox(height: 20),
            const Text('Scheduled Medical Reports:', style: TextStyle(fontSize: 18)),
            Expanded(
              child: ListView.builder(
                itemCount: medicalReports.length,
                itemBuilder: (context, index) {
                  final report = medicalReports[index];
                  return ListTile(
                    title: Text('Condition: ${report.condition}'),
                    subtitle: Text('Report Time: ${report.reportDateTime.toLocal()}'),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
