package com.example.healthify.healthify

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
